"""Run from the repository root: python train.py."""
from src.churn import run_experiment

if __name__ == "__main__":
    result = run_experiment()
    name = result["selected_model"]
    metrics = result["test"][name]
    print(f"Selected on validation: {name}")
    print(f"Test ROC-AUC: {metrics['roc_auc']:.4f}; AP: {metrics['average_precision']:.4f}; F1: {metrics['f1']:.4f}")
    print("Saved models, metrics, figures, split audit and SQL analysis.")
