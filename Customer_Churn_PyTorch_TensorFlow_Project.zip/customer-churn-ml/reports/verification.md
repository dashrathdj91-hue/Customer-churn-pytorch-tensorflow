# Verification record

Run for the delivered package on 2026-09-29.

- Full training completed for majority baseline, Logistic Regression, Random Forest, PyTorch MLP and TensorFlow MLP.
- `python -m pytest -q`: 8 passed. Checks cover checksum/deduplication, group isolation, excluded fields, zero calls/schema errors, training-only transforms, validation thresholding, inference consistency and both neural checkpoints.
- `python predict.py --input data/example_customers.csv --output reports/example_predictions.csv`: 5 rows scored.
- `python scripts/execute_notebook.py`: 10 Python cells executed with IPython in-process; zero notebook errors and five embedded figures.
- The default notebook displays the completed training artifacts. Set RETRAIN=True or run train.py to rebuild them.
- Resume is one A4 page; PDF text and rendered layout checked.
- Tested on Linux/Python 3.12.14. Other operating systems were not run here.
