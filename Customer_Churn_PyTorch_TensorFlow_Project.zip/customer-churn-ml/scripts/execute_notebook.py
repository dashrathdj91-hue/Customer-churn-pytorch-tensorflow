"""Execute the Python-only notebook with IPython, without network sockets."""
import os
from pathlib import Path
import nbformat
from IPython.core.interactiveshell import InteractiveShell
from IPython.utils.capture import capture_output

root = Path(__file__).resolve().parents[1]
path = root / "notebooks/customer_churn_walkthrough.ipynb"
nb = nbformat.read(path, as_version=4)
shell = InteractiveShell.instance()
os.chdir(root)
count = 0
for cell in nb.cells:
    if cell.cell_type != "code":
        continue
    count += 1
    cell.execution_count = count
    with capture_output(stdout=True, stderr=True, display=True) as captured:
        result = shell.run_cell(cell.source, store_history=False)
    outputs = []
    if captured.stdout:
        outputs.append(nbformat.v4.new_output("stream", name="stdout", text=captured.stdout))
    if captured.stderr:
        outputs.append(nbformat.v4.new_output("stream", name="stderr", text=captured.stderr))
    for rich in captured.outputs:
        outputs.append(nbformat.v4.new_output("display_data", data=rich.data, metadata=rich.metadata))
    cell.outputs = outputs
    error = result.error_before_exec or result.error_in_exec
    if error:
        raise RuntimeError(f"Notebook cell {count} failed") from error
nb.metadata["execution"] = {"method": "IPython in-process", "code_cells_executed": count}
nbformat.validate(nb)
nbformat.write(nb, path)
print(f"Executed {count} code cells successfully: {path.name}")
