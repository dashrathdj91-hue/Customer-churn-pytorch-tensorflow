"""Optional recovery if the bundled, attributed raw CSV is missing."""
import hashlib
import io
from pathlib import Path
from urllib.request import urlopen
from zipfile import ZipFile

URL = "https://archive.ics.uci.edu/static/public/563/iranian+churn+dataset.zip"
EXPECTED = "90d5fb6bd1630cd4de4b4d28fcf8b4cb92a8f6ab7484605b0799d47386f7dbe1"

if __name__ == "__main__":
    payload = urlopen(URL, timeout=60).read()
    with ZipFile(io.BytesIO(payload)) as archive:
        data = archive.read("Customer Churn.csv")
    if hashlib.sha256(data).hexdigest() != EXPECTED:
        raise ValueError("Source checksum changed; refusing to overwrite bundled data.")
    path = Path(__file__).resolve().parents[1] / "data/raw/customer_churn.csv"
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    print(path)
