"""Example: python predict.py --input data/example_customers.csv --output predictions.csv"""
import argparse
from pathlib import Path
import pandas as pd
from src.churn import predict_customers

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", default=Path("predictions.csv"), type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.input)
    scored = predict_customers(frame)
    output = pd.concat([frame.reset_index(drop=True), scored], axis=1)
    output.to_csv(args.output, index=False)
    print(f"Scored {len(output)} rows: {args.output}")
