-- Training partition only. Observed associations, not causal treatment effects.
SELECT
    CASE complains WHEN 1 THEN 'Complaint recorded' ELSE 'No complaint' END AS complaint_segment,
    CASE tariff_plan WHEN 1 THEN 'Pay as you go' ELSE 'Contractual' END AS tariff_segment,
    COUNT(*) AS customers,
    SUM(churn) AS churned_customers,
    ROUND(100.0 * AVG(churn), 2) AS churn_rate_pct,
    ROUND(AVG(subscription_length), 1) AS avg_subscription_months
FROM customers
WHERE partition = 'train'
GROUP BY complains, tariff_plan
ORDER BY churn_rate_pct DESC;
