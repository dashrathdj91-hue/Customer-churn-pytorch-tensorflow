# Data provenance

- Dataset: Iranian Churn, UCI Machine Learning Repository, 2020.
- DOI: https://doi.org/10.24432/C5JW3Z
- Source: https://archive.ics.uci.edu/dataset/563/iranian+churn+dataset
- Download: https://archive.ics.uci.edu/static/public/563/iranian+churn+dataset.zip
- Original archive member: `Customer Churn.csv`.
- Bundled location: `data/raw/customer_churn.csv` (bytes unchanged).
- License: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/.
- SHA-256: `90d5fb6bd1630cd4de4b4d28fcf8b4cb92a8f6ab7484605b0799d47386f7dbe1`.
- Retrieved for this project: 2026-09-29.

Changes in derived data: normalize whitespace/case in column names, drop 300 exact duplicate rows, retain original row position as `source_row`. Model inputs omit status, customer value and demographic fields and add two deterministic call-usage ratios. `source_row` and `churn` are never model inputs. Cleaned data has 2,850 rows.

The data is historical and from one telecom context. No insurance-company customer data is used. The sample input contains five rows from this public dataset and is for demonstration, not new independently collected customers.
