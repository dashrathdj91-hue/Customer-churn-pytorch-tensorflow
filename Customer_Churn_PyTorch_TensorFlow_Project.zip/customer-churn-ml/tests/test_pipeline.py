"""Checks for data leakage, input handling and saved-artifact consistency."""
import json
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import pytest
import tensorflow as tf
import torch

from src.churn import (
    BASE_FEATURES, ROOT, ChurnNetwork, build_features, choose_threshold,
    load_clean_data, make_split, predict_customers, preprocessor,
    tensorflow_scores, torch_scores,
)


def test_raw_integrity_and_duplicate_cleanup():
    df, x, quality = load_clean_data()
    assert (quality["raw_rows"], quality["exact_duplicates_removed"], len(df)) == (3150, 300, 2850)
    assert not df.drop(columns="source_row").duplicated().any()
    assert set(df.churn) == {0, 1}
    assert np.isfinite(x.to_numpy()).all()


def test_feature_groups_never_cross_partitions():
    df, x, _ = load_clean_data()
    split, groups = make_split(x, df.churn)
    assert set(split) == {"train", "validation", "test"}
    for a, b in [("train", "validation"), ("train", "test"), ("validation", "test")]:
        assert set(groups[split == a]).isdisjoint(groups[split == b])


def test_target_and_excluded_fields_do_not_affect_features():
    df, original, _ = load_clean_data()
    changed = df.copy()
    changed["churn"] = 1 - changed.churn
    for col in ["status", "age", "age_group", "customer_value"]:
        changed[col] = -999
    pd.testing.assert_frame_equal(original, build_features(changed))


def test_zero_calls_and_missing_schema():
    df, _, _ = load_clean_data()
    example = df.iloc[:2].copy()
    example["frequency_of_use"] = 0
    assert np.isfinite(build_features(example).to_numpy()).all()
    with pytest.raises(ValueError, match="Missing required columns"):
        build_features(example.drop(columns="complains"))


def test_preprocessing_does_not_learn_from_holdout():
    df, x, _ = load_clean_data()
    split, _ = make_split(x, df.churn)
    train = x.loc[split == "train"]
    prep = preprocessor().fit(train)
    scaler = prep.named_transformers_["numeric"].named_steps["scale"]
    before = scaler.mean_.copy()
    extreme = x.loc[split == "test"].copy()
    extreme["seconds_of_use"] = 1e12
    prep.transform(extreme)
    np.testing.assert_array_equal(scaler.mean_, before)
    numeric = [c for c in train if c != "tariff_plan"]
    np.testing.assert_allclose(before, train[numeric].mean().to_numpy())


def test_threshold_uses_validation_f1():
    y = np.array([0, 0, 1, 1])
    p = np.array([0.1, 0.2, 0.35, 0.4])
    threshold = choose_threshold(y, p)
    np.testing.assert_array_equal(p >= threshold, y)


def test_saved_selected_model_reproduces_test_predictions():
    df, _, _ = load_clean_data()
    expected = pd.read_csv(ROOT / "reports/test_predictions.csv")
    rows = df.set_index("source_row").loc[expected.source_row]
    actual = predict_customers(rows)
    np.testing.assert_allclose(actual.churn_score, expected.churn_score, rtol=1e-6, atol=1e-7)
    np.testing.assert_array_equal(actual.predicted_churn, expected.predicted_churn)


def test_both_neural_artifacts_load_and_score():
    df, x, _ = load_clean_data()
    prep = joblib.load(ROOT / "models/neural_preprocessor.joblib")
    sample = prep.transform(x.iloc[:7]).astype(np.float32)
    checkpoint = torch.load(ROOT / "models/pytorch_mlp.pt", map_location="cpu", weights_only=True)
    net = ChurnNetwork(checkpoint["input_size"])
    net.load_state_dict(checkpoint["state_dict"])
    tf_net = tf.keras.models.load_model(ROOT / "models/tensorflow_mlp.keras", compile=False)
    for scores in [torch_scores(net, sample), tensorflow_scores(tf_net, sample)]:
        assert scores.shape == (7,)
        assert np.isfinite(scores).all()
        assert ((scores >= 0) & (scores <= 1)).all()
