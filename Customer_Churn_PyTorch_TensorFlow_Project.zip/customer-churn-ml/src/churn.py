"""Training, evaluation and inference for a small public-data churn benchmark.

All data-dependent transforms are fitted on the training partition only.
Model selection, early stopping and the F1 threshold use validation labels.
The test partition is scored only after those choices have been frozen.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
import platform
import re
import sqlite3
from pathlib import Path

import joblib
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sklearn
os.environ.setdefault("TF_CPP_MIN_LOG_LEVEL", "2")
os.environ.setdefault("TF_ENABLE_ONEDNN_OPTS", "0")
import tensorflow as tf
import torch
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, average_precision_score, balanced_accuracy_score,
    confusion_matrix, f1_score, precision_recall_curve, precision_score,
    recall_score, roc_auc_score, roc_curve,
)
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from torch import nn
from torch.utils.data import DataLoader, TensorDataset

ROOT = Path(__file__).resolve().parents[1]
SEED = 42
RAW_SHA256 = "90d5fb6bd1630cd4de4b4d28fcf8b4cb92a8f6ab7484605b0799d47386f7dbe1"
BASE_FEATURES = [
    "call_failure", "complains", "subscription_length", "charge_amount",
    "seconds_of_use", "frequency_of_use", "frequency_of_sms",
    "distinct_called_numbers", "tariff_plan",
]
FEATURES = BASE_FEATURES + ["seconds_per_call", "failures_per_call"]


def normalize_columns(df: pd.DataFrame) -> pd.DataFrame:
    result = df.copy()
    result.columns = [re.sub(r"\s+", "_", c.strip().lower()) for c in result.columns]
    if result.columns.duplicated().any():
        raise ValueError("Column names are not unique after normalization.")
    return result


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Deterministic, label-free features; no statistics are learned here."""
    df = normalize_columns(df)
    missing = sorted(set(BASE_FEATURES) - set(df.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    x = df[BASE_FEATURES].apply(pd.to_numeric, errors="raise").astype(float)
    if np.isinf(x.to_numpy()).any() or (x < 0).any().any():
        raise ValueError("Features must be nonnegative and finite (NaN is allowed).")
    if not set(x.complains.dropna().unique()).issubset({0, 1}):
        raise ValueError("complains must be 0 or 1.")
    # +1 keeps these ratios defined for zero-call customers.
    x["seconds_per_call"] = x.seconds_of_use / (x.frequency_of_use + 1)
    x["failures_per_call"] = x.call_failure / (x.frequency_of_use + 1)
    return x[FEATURES]


def load_clean_data(path: Path | None = None):
    path = path or ROOT / "data/raw/customer_churn.csv"
    raw_bytes = path.read_bytes()
    digest = hashlib.sha256(raw_bytes).hexdigest()
    if digest != RAW_SHA256:
        raise ValueError("Raw dataset checksum changed; inspect the source before training.")
    raw = normalize_columns(pd.read_csv(path))
    if len(raw) != 3150 or set(raw.churn.unique()) != {0, 1}:
        raise ValueError("Unexpected dataset shape or target values.")
    # Retain original row position for auditability; it is never a feature.
    kept = raw.loc[~raw.duplicated()].copy()
    kept.insert(0, "source_row", kept.index.to_numpy())
    kept = kept.reset_index(drop=True)
    x = build_features(kept)
    quality = {
        "raw_rows": len(raw), "exact_duplicates_removed": len(raw) - len(kept),
        "clean_rows": len(kept), "missing_values": int(raw.isna().sum().sum()),
        "sha256": digest, "raw_churn_rate": float(raw.churn.mean()),
        "clean_churn_rate": float(kept.churn.mean()),
        "feature_count": len(FEATURES),
        "excluded_fields": ["status", "customer_value", "age", "age_group"],
    }
    return kept, x, quality


def make_split(x: pd.DataFrame, y: pd.Series):
    """Approx. 60/20/20 split, keeping identical feature profiles together."""
    groups = pd.util.hash_pandas_object(x, index=False).astype(str).to_numpy()
    folds = np.empty(len(x), dtype=int)
    splitter = StratifiedGroupKFold(n_splits=5, shuffle=True, random_state=SEED)
    for fold, (_, ids) in enumerate(splitter.split(x, y, groups)):
        folds[ids] = fold
    split = np.where(folds == 0, "test", np.where(folds == 1, "validation", "train"))
    for a, b in [("train", "test"), ("train", "validation"), ("validation", "test")]:
        assert set(groups[split == a]).isdisjoint(groups[split == b])
    return split, groups


def preprocessor():
    numeric = [c for c in FEATURES if c != "tariff_plan"]
    return ColumnTransformer([
        ("numeric", Pipeline([("impute", SimpleImputer(strategy="median")),
                              ("scale", StandardScaler())]), numeric),
        ("tariff", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                             ("encode", OneHotEncoder(handle_unknown="ignore", sparse_output=False))]),
         ["tariff_plan"]),
    ], sparse_threshold=0)


class ChurnNetwork(nn.Module):
    def __init__(self, input_size: int):
        super().__init__()
        self.layers = nn.Sequential(nn.Linear(input_size, 32), nn.ReLU(), nn.Dropout(0.1),
                                    nn.Linear(32, 16), nn.ReLU(), nn.Linear(16, 1))

    def forward(self, x):
        return self.layers(x).squeeze(-1)


def torch_scores(model, x):
    model.eval()
    with torch.no_grad():
        return torch.sigmoid(model(torch.as_tensor(x, dtype=torch.float32))).numpy()


def train_network(x_train, y_train, x_val, y_val):
    torch.manual_seed(SEED)
    torch.set_num_threads(2)
    torch.use_deterministic_algorithms(True)
    model = ChurnNetwork(x_train.shape[1])
    pos_weight = torch.tensor(float((y_train == 0).sum() / (y_train == 1).sum()))
    loss_fn = nn.BCEWithLogitsLoss(pos_weight=pos_weight)
    optimizer = torch.optim.Adam(model.parameters(), lr=0.003, weight_decay=0.001)
    loader = DataLoader(TensorDataset(torch.tensor(x_train, dtype=torch.float32),
                                    torch.tensor(y_train, dtype=torch.float32)),
                        batch_size=64, shuffle=True,
                        generator=torch.Generator().manual_seed(SEED))
    best_ap, best_state, best_epoch, stale = -1.0, None, 0, 0
    history = []
    for epoch in range(1, 151):
        model.train()
        total_loss = 0.0
        for xb, yb in loader:
            optimizer.zero_grad()
            loss = loss_fn(model(xb), yb)
            loss.backward()
            optimizer.step()
            total_loss += loss.item() * len(xb)
        val_ap = average_precision_score(y_val, torch_scores(model, x_val))
        history.append({"epoch": epoch, "weighted_train_loss": total_loss / len(y_train),
                        "validation_average_precision": val_ap})
        if val_ap > best_ap + 1e-5:
            best_ap, best_state, best_epoch, stale = val_ap, copy.deepcopy(model.state_dict()), epoch, 0
        else:
            stale += 1
        if stale >= 20:
            break
    model.load_state_dict(best_state)
    return model, pd.DataFrame(history), best_epoch


def tensorflow_scores(model, x):
    return tf.math.sigmoid(model(np.asarray(x, dtype=np.float32), training=False)).numpy().ravel()


def train_tensorflow(x_train, y_train, x_val, y_val):
    """Same small architecture in Keras; framework results need not be identical."""
    try:
        tf.config.threading.set_inter_op_parallelism_threads(2)
        tf.config.threading.set_intra_op_parallelism_threads(2)
    except RuntimeError:
        pass  # A notebook may already have initialized the TF runtime.
    tf.keras.utils.set_random_seed(SEED)
    tf.config.experimental.enable_op_determinism()
    model = tf.keras.Sequential([
        tf.keras.Input(shape=(x_train.shape[1],)),
        tf.keras.layers.Dense(32, activation="relu"),
        tf.keras.layers.Dropout(0.1, seed=SEED),
        tf.keras.layers.Dense(16, activation="relu"),
        tf.keras.layers.Dense(1),
    ])
    optimizer = tf.keras.optimizers.Adam(learning_rate=0.003, weight_decay=0.001)
    pos_weight = np.float32((y_train == 0).sum() / (y_train == 1).sum())

    @tf.function(reduce_retracing=True)
    def train_batch(xb, yb):
        with tf.GradientTape() as tape:
            logits = tf.squeeze(model(xb, training=True), axis=-1)
            loss = tf.reduce_mean(tf.nn.weighted_cross_entropy_with_logits(
                labels=yb, logits=logits, pos_weight=pos_weight))
        gradients = tape.gradient(loss, model.trainable_variables)
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))
        return loss

    best_ap, best_weights, best_epoch, stale = -1.0, None, 0, 0
    rng, history = np.random.default_rng(SEED), []
    for epoch in range(1, 151):
        order = rng.permutation(len(y_train))
        total = 0.0
        for start in range(0, len(order), 64):
            batch = order[start:start + 64]
            loss = train_batch(x_train[batch], y_train[batch].astype(np.float32))
            total += float(loss.numpy()) * len(batch)
        val_ap = average_precision_score(y_val, tensorflow_scores(model, x_val))
        history.append({"epoch": epoch, "weighted_train_loss": total / len(y_train),
                        "validation_average_precision": val_ap})
        if val_ap > best_ap + 1e-5:
            best_ap, best_weights, best_epoch, stale = val_ap, model.get_weights(), epoch, 0
        else:
            stale += 1
        if stale >= 20:
            break
    model.set_weights(best_weights)
    return model, pd.DataFrame(history), best_epoch


def choose_threshold(y_validation, scores):
    """Choose F1 threshold on validation only; stable tie-break near 0.5."""
    candidates = np.linspace(0.05, 0.95, 91)
    return float(max(candidates, key=lambda t: (
        f1_score(y_validation, scores >= t, zero_division=0), -abs(t - 0.5))))


def evaluate(y, scores, threshold):
    labels = np.asarray(scores) >= threshold
    k = max(1, math.ceil(0.2 * len(y)))
    top = np.argsort(-np.asarray(scores), kind="stable")[:k]
    y = np.asarray(y)
    precision_top = float(y[top].mean())
    return {
        "roc_auc": float(roc_auc_score(y, scores)),
        "average_precision": float(average_precision_score(y, scores)),
        "accuracy": float(accuracy_score(y, labels)),
        "balanced_accuracy": float(balanced_accuracy_score(y, labels)),
        "precision": float(precision_score(y, labels, zero_division=0)),
        "recall": float(recall_score(y, labels, zero_division=0)),
        "f1": float(f1_score(y, labels, zero_division=0)),
        "threshold": float(threshold), "contact_count_top20": k,
        "precision_top20": precision_top, "recall_top20": float(y[top].sum() / y.sum()),
        "lift_top20": float(precision_top / y.mean()),
        "confusion_matrix": confusion_matrix(y, labels, labels=[0, 1]).tolist(),
    }


def plot_results(root, scores, y_test, selected, threshold, train_df, history, tf_history):
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "figure.dpi": 140})
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), constrained_layout=True)
    for i, (name, values) in enumerate(scores.items()):
        color = f"C{i}"
        fpr, tpr, _ = roc_curve(y_test, values)
        prec, rec, _ = precision_recall_curve(y_test, values)
        axes[0].plot(fpr, tpr, label=name, color=color)
        if name == "Majority baseline":
            axes[1].axhline(y_test.mean(), ls="--", c="grey", label="No-skill prevalence")
        else:
            axes[1].step(rec, prec, where="post", label=name, color=color)
    axes[0].plot([0, 1], [0, 1], "--", c="grey", alpha=0.5)
    axes[0].set(title="Held-out ROC curves", xlabel="False positive rate", ylabel="True positive rate")
    axes[1].set(title="Held-out precision-recall curves", xlabel="Recall", ylabel="Precision")
    axes[1].legend(fontsize=8)
    fig.savefig(root / "curves.png"); plt.close(fig)

    cm = confusion_matrix(y_test, scores[selected] >= threshold, labels=[0, 1])
    fig, ax = plt.subplots(figsize=(4.7, 4.1), constrained_layout=True)
    ax.imshow(cm, cmap="Blues")
    for i in range(2):
        for j in range(2):
            ax.text(j, i, str(cm[i, j]), ha="center", va="center", fontsize=20,
                    color="white" if cm[i, j] > cm.max() / 2 else "#203A63")
    ax.set(xticks=[0, 1], yticks=[0, 1], xticklabels=["Stay", "Churn"],
           yticklabels=["Stay", "Churn"], xlabel="Predicted", ylabel="Actual",
           title=f"{selected}: test confusion matrix")
    fig.savefig(root / "confusion_matrix.png"); plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(10, 3.7), constrained_layout=True)
    train_df.churn.value_counts().sort_index().plot.bar(ax=axes[0], color=["#2E6078", "#D9824B"], rot=0)
    axes[0].set(title="Training labels", xlabel="Churn (0 = no, 1 = yes)", ylabel="Customers")
    (train_df.groupby("complains").churn.mean() * 100).plot.bar(ax=axes[1], color="#2E6078", rot=0)
    axes[1].set(title="Training churn rate by complaint flag", xlabel="Complaint (0 = no, 1 = yes)", ylabel="Churn rate (%)")
    fig.savefig(root / "training_eda.png"); plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 3.5), constrained_layout=True)
    ax.plot(history.epoch, history.validation_average_precision, color="#2E6078", label="PyTorch")
    ax.plot(tf_history.epoch, tf_history.validation_average_precision, color="#D9824B", label="TensorFlow")
    ax.set(title="Neural network learning curves", xlabel="Epoch", ylabel="Validation average precision")
    ax.legend()
    fig.savefig(root / "neural_network_learning.png"); plt.close(fig)


def run_experiment(root: Path = ROOT):
    root = Path(root)
    models, reports = root / "models", root / "reports"
    for folder in [models, reports, root / "data/processed"]:
        folder.mkdir(parents=True, exist_ok=True)
    df, x, quality = load_clean_data(root / "data/raw/customer_churn.csv")
    y = df.churn.astype(int)
    split, groups = make_split(x, y)
    ids = {s: np.flatnonzero(split == s) for s in ["train", "validation", "test"]}
    xt, xv, xe = [x.iloc[ids[s]] for s in ids]
    yt, yv, ye = [y.iloc[ids[s]].to_numpy() for s in ids]
    quality["split"] = {s: {"rows": len(ids[s]), "churn_rate": float(y.iloc[ids[s]].mean())} for s in ids}
    quality["unique_feature_profiles"] = int(len(set(groups)))
    df.to_csv(root / "data/processed/customers_clean.csv", index=False)
    pd.DataFrame({"source_row": df.source_row, "split": split, "feature_group": groups,
                  "churn": y}).to_csv(reports / "split_manifest.csv", index=False)

    candidates = {
        "Majority baseline": DummyClassifier(strategy="most_frequent"),
        "Logistic Regression": LogisticRegression(class_weight="balanced", max_iter=2000, random_state=SEED),
        "Random Forest": RandomForestClassifier(n_estimators=300, max_depth=10, min_samples_leaf=3,
                                                 class_weight="balanced", random_state=SEED, n_jobs=2),
    }
    fitted, val_scores = {}, {}
    for name, estimator in candidates.items():
        pipe = Pipeline([("preprocess", preprocessor()), ("classifier", estimator)])
        pipe.fit(xt, yt)
        fitted[name] = pipe
        val_scores[name] = pipe.predict_proba(xv)[:, 1]
    prep = preprocessor()
    nt = prep.fit_transform(xt).astype(np.float32)
    nv = prep.transform(xv).astype(np.float32)
    net, history, best_epoch = train_network(nt, yt, nv, yv)
    tf_net, tf_history, tf_best_epoch = train_tensorflow(nt, yt, nv, yv)
    history.to_csv(reports / "neural_training_history.csv", index=False)
    tf_history.to_csv(reports / "tensorflow_training_history.csv", index=False)
    val_scores["PyTorch MLP"] = torch_scores(net, nv)
    val_scores["TensorFlow MLP"] = tensorflow_scores(tf_net, nv)

    thresholds = {name: choose_threshold(yv, p) for name, p in val_scores.items()}
    validation = {name: evaluate(yv, p, thresholds[name]) for name, p in val_scores.items()}
    selected = max(validation, key=lambda n: validation[n]["average_precision"])
    # All model and threshold choices are frozen above this line.
    test_scores = {name: pipe.predict_proba(xe)[:, 1] for name, pipe in fitted.items()}
    test_scores["PyTorch MLP"] = torch_scores(net, prep.transform(xe).astype(np.float32))
    test_scores["TensorFlow MLP"] = tensorflow_scores(tf_net, prep.transform(xe).astype(np.float32))
    test = {name: evaluate(ye, p, thresholds[name]) for name, p in test_scores.items()}
    pd.DataFrame({"source_row": df.iloc[ids["test"]].source_row.to_numpy(),
                  "actual_churn": ye, **test_scores}).to_csv(reports / "all_model_test_scores.csv", index=False)
    result = {
        "seed": SEED, "dataset": quality, "selection_metric": "validation average precision",
        "selected_model": selected, "threshold_rule": "Maximum validation F1 on 0.05..0.95 grid",
        "selected_threshold": thresholds[selected], "validation": validation, "test": test,
        "neural_network": {"best_epoch": best_epoch, "epochs_run": len(history),
                           "architecture": [nt.shape[1], 32, 16, 1], "dropout": 0.1,
                           "learning_rate": 0.003, "weight_decay": 0.001,
                           "max_epochs": 150, "patience": 20, "batch_size": 64},
        "tensorflow_network": {"best_epoch": tf_best_epoch, "epochs_run": len(tf_history),
                               "architecture": [nt.shape[1], 32, 16, 1],
                               "same_hyperparameters_as_pytorch": True},
        "environment": {"python": platform.python_version(), "numpy": np.__version__,
                        "pandas": pd.__version__, "scikit_learn": sklearn.__version__,
                        "torch": torch.__version__, "tensorflow": tf.__version__,
                        "joblib": joblib.__version__},
    }
    (reports / "metrics.json").write_text(json.dumps(result, indent=2))
    rows = [{"partition": s, "model": n, **{k: v for k, v in r.items() if k != "confusion_matrix"}}
            for s, scores in [("validation", validation), ("test", test)] for n, r in scores.items()]
    pd.DataFrame(rows).to_csv(reports / "model_comparison.csv", index=False)
    pd.DataFrame({"source_row": df.iloc[ids["test"]].source_row.to_numpy(), "actual_churn": ye,
                  "churn_score": test_scores[selected],
                  "predicted_churn": (test_scores[selected] >= thresholds[selected]).astype(int)
                  }).to_csv(reports / "test_predictions.csv", index=False)

    torch.save({"input_size": nt.shape[1], "state_dict": net.state_dict()}, models / "pytorch_mlp.pt")
    tf_net.save(models / "tensorflow_mlp.keras")
    joblib.dump(prep, models / "neural_preprocessor.joblib", compress=3)
    if selected in fitted:
        joblib.dump(fitted[selected], models / "selected_model.joblib", compress=3)
    metadata = {"selected_model": selected, "threshold": thresholds[selected],
                "features": FEATURES, "dataset_sha256": RAW_SHA256,
                "training_environment": result["environment"]}
    (models / "metadata.json").write_text(json.dumps(metadata, indent=2))

    # Interpretation is calculated on validation data, not used for feature retuning.
    def score_fn(frame):
        if selected == "PyTorch MLP":
            return torch_scores(net, prep.transform(frame).astype(np.float32))
        if selected == "TensorFlow MLP":
            return tensorflow_scores(tf_net, prep.transform(frame).astype(np.float32))
        return fitted[selected].predict_proba(frame)[:, 1]
    base = average_precision_score(yv, score_fn(xv))
    rng, importance = np.random.default_rng(SEED), []
    for col in FEATURES:
        changes = []
        for _ in range(5):
            shuffled = xv.copy()
            shuffled[col] = rng.permutation(shuffled[col].to_numpy())
            changes.append(base - average_precision_score(yv, score_fn(shuffled)))
        importance.append({"feature": col, "mean_ap_drop": np.mean(changes), "std_ap_drop": np.std(changes)})
    importance = pd.DataFrame(importance).sort_values("mean_ap_drop", ascending=False)
    importance.to_csv(reports / "validation_feature_importance.csv", index=False)
    fig, ax = plt.subplots(figsize=(8, 4.3), constrained_layout=True)
    importance.iloc[::-1].plot.barh(x="feature", y="mean_ap_drop", ax=ax, legend=False, color="#2E6078")
    ax.set(title=f"{selected}: validation permutation importance", xlabel="Drop in average precision", ylabel="")
    fig.savefig(reports / "feature_importance.png"); plt.close(fig)

    plot_results(reports, test_scores, ye, selected, thresholds[selected], df.iloc[ids["train"]], history, tf_history)
    with sqlite3.connect(root / "data/processed/churn.sqlite") as conn:
        df.assign(partition=split).to_sql("customers", conn, index=False, if_exists="replace")
        query = (root / "sql/retention_analysis.sql").read_text()
        sql_result = pd.read_sql_query(query, conn)
        sql_result.to_csv(reports / "sql_retention_segments.csv", index=False)
    return result


def predict_customers(df: pd.DataFrame, model_dir: Path | None = None):
    """Score raw source-format or normalized columns using saved training artifacts."""
    model_dir = Path(model_dir or ROOT / "models")
    meta = json.loads((model_dir / "metadata.json").read_text())
    x = build_features(df)
    if meta["selected_model"] == "PyTorch MLP":
        checkpoint = torch.load(model_dir / "pytorch_mlp.pt", map_location="cpu", weights_only=True)
        model = ChurnNetwork(checkpoint["input_size"])
        model.load_state_dict(checkpoint["state_dict"])
        prep = joblib.load(model_dir / "neural_preprocessor.joblib")
        scores = torch_scores(model, prep.transform(x).astype(np.float32))
    elif meta["selected_model"] == "TensorFlow MLP":
        model = tf.keras.models.load_model(model_dir / "tensorflow_mlp.keras", compile=False)
        prep = joblib.load(model_dir / "neural_preprocessor.joblib")
        scores = tensorflow_scores(model, prep.transform(x).astype(np.float32))
    else:
        model = joblib.load(model_dir / "selected_model.joblib")
        scores = model.predict_proba(x)[:, 1]
    return pd.DataFrame({"churn_score": scores,
                         "predicted_churn": (scores >= meta["threshold"]).astype(int)})
