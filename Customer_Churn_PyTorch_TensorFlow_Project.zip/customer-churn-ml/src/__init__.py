"""Reproducible customer churn portfolio project."""
