# Model card

## Intended use

Educational comparison of customer churn classifiers and a demonstration of retention prioritization. This is a guided portfolio project. It is not a deployed service and has not produced a measured reduction in churn.

## Data and features

Raw rows: 3150; deduplicated rows: 2850; raw churn prevalence: 15.71%; retained prevalence: 15.65%. Nine operational columns plus two usage ratios are modeled. Age, age group, status and customer value are excluded. No customer identifiers enter the model.

## Model and decision rule

Selected: **TensorFlow MLP**. Selection uses validation AP. Saved threshold: **0.75**, chosen on validation F1. Saved networks and preprocessors were trained only on the training partition. Both frameworks' checkpoints are included, even though only one candidate is selected for default inference.

## Test evaluation

| Model | Validation AP | Test ROC-AUC | Test AP | Test precision | Test recall | Test F1 |
|---|---|---|---|---|---|---|
| Majority baseline | 0.156 | 0.500 | 0.159 | 0.000 | 0.000 | 0.000 |
| Logistic Regression | 0.742 | 0.929 | 0.746 | 0.503 | 0.802 | 0.619 |
| Random Forest | 0.878 | 0.971 | 0.877 | 0.669 | 0.868 | 0.756 |
| PyTorch MLP | 0.910 | 0.978 | 0.909 | 0.800 | 0.791 | 0.796 |
| TensorFlow MLP | 0.922 | 0.978 | 0.907 | 0.762 | 0.846 | 0.802 |

Winner test confusion matrix (rows actual 0/1, columns predicted 0/1): `[[458, 24], [14, 77]]`.
Test ROC-AUC 0.9777, AP 0.9070, F1 0.8021. At the illustrative top-20% capacity, precision is 69.57% and recall is 87.91%.

## Limits

- One small, historical dataset and one fixed split; these are point estimates without confidence intervals or repeated-split stability analysis.
- Grouping stops exact feature-profile overlap; near-duplicates can remain. Without source customer identifiers, independence cannot be fully established.
- There are no row-level dates for a true time-based test or drift measurement.
- Data is from a telecom context, not an insurance portfolio; transfer to other businesses is untested.
- Class weighting means scores are not calibrated probabilities. No calibrated probability, campaign ROI or causal retention effect is claimed.
- Excluding demographic inputs does not establish fairness; fairness was not evaluated.
- Validation is reused for early stopping and model/threshold selection. A larger nested or temporal evaluation would improve reliability.
- The reported winner was not chosen from test results. Test reporting must not become a repeated tuning loop.

## Reproducibility

See `reports/metrics.json` for versions, seed, partitions and epoch selection; `reports/split_manifest.csv` for assignments; and `DATA_SOURCE.md` for the source hash. Small numerical differences across platforms and package builds are possible. Input requirements and inference are documented in README and the notebook.
