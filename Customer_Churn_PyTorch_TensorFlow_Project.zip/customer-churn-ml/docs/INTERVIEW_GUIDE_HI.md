# Project समझें और interview में समझाएँ

## एक मिनट का परिचय

“इस portfolio project में मैंने public telecom data पर churn prediction workflow का अध्ययन और implementation किया। Data cleaning और leakage-safe split के बाद Logistic Regression, Random Forest, PyTorch और TensorFlow models की तुलना की। Validation average precision से TensorFlow MLP चुना गया। अलग test set पर ROC-AUC 0.978, average precision 0.907 और F1 0.802 मिले।”

इसे बोलने से पहले notebook चलाएँ और हर step अपने शब्दों में समझें। Project AI assistance से तैयार हुआ है; केवल वही जिम्मेदारी और skill level बताएँ जिसे आप समझा और प्रदर्शित कर सकते हैं। इसे production experience न बताएँ।

## 1. समस्या क्या है?

Churn का मतलब customer का service छोड़ना है। Historical usage के आधार पर एक score बनता है जिससे retention team review की प्राथमिकता तय कर सकती है। किसी customer को रोक पाने का कारण या guaranteed result model नहीं बताता।

## 2. Dataset कितना बड़ा है?

3,150 raw rows; 300 exact duplicate rows हटाने के बाद 2,850 records। Dataset UCI Iranian Churn है। यह HDFC या किसी employer का data नहीं है।

## 3. Data leakage कैसे रोका?

- पहले same records की duplicates हटाईं।
- समान input features वाली rows को एक group में रखा, ताकि वे train और test में साथ न पहुँचें।
- Imputer, scaler और encoder केवल training data पर fit हुए।
- Model, epoch और threshold validation से चुने; test केवल final reporting के लिए था।

## 4. PyTorch और TensorFlow में क्या किया?

दोनों में छोटा dense neural network: input → 32 neurons/ReLU → dropout → 16 neurons/ReLU → output logit।

**PyTorch:** nn.Module, DataLoader, BCEWithLogitsLoss, loss.backward(), optimizer.step(), state_dict।

**TensorFlow/Keras:** Sequential, Dense, Dropout, GradientTape, weighted cross entropy, apply_gradients और .keras model save/load।

दोनों के random initializations और implementation अलग हैं; scores का बिल्कुल समान होना जरूरी नहीं है।

## 5. Epoch, learning rate और dropout?

Epoch training data का एक पूरा pass है। Learning rate weight update का आकार तय करता है। Dropout training के समय कुछ activations को बंद करके overfitting घटाने में मदद करता है। यहाँ dropout 0.1 और learning rate 0.003 हैं।

## 6. Class weighting क्यों?

Churners minority class हैं। Weighted loss positive-class errors को अधिक महत्व देता है। इससे हर बार recall या precision बढ़ना तय नहीं होता; validation पर जाँचना पड़ता है।

## 7. Accuracy से ज्यादा AP/F1 क्यों?

सभी customers को non-churn कहकर भी बड़ी accuracy मिल सकती है। Precision बताता है flagged customers में कितने सही थे। Recall बताता है असली churners में कितने पकड़े। F1 precision और recall का harmonic mean है। Average precision अलग thresholds पर ranking quality का summary है।

## 8. Threshold 0.5 ही क्यों नहीं?

Score को 0/1 label में बदलने के लिए threshold चाहिए। यहाँ validation F1 सबसे अच्छा करने वाला threshold 0.75 है। Business में outreach cost और capacity के अनुसार अलग threshold चुन सकते हैं; उसके लिए नए validation data की जरूरत होगी।

## 9. Business result क्या है?

इस test set के highest-scored 20% में 87.9% churners आते हैं। यह ranking result है; इससे वास्तविक churn reduction या revenue बचत सिद्ध नहीं होती।

## 10. किस model को deploy किया?

कोई production deployment नहीं किया। Saved model और prediction CLI बनाया है। Deployment से पहले temporal evaluation, calibration, monitoring, security और business testing की जरूरत होगी।

## Practice checklist

1. README के commands से project चलाएँ।
2. Notebook में TRAIN/validation/test counts देखें।
3. PyTorch और TensorFlow training functions पढ़ें।
4. Test confusion matrix से precision/recall स्वयं निकालें।
5. Sample input की values बदलकर prediction command चलाएँ।
6. GitHub पर README, code, notebook, data attribution और results upload करें।
7. Resume में इसे portfolio project और introductory framework exposure के रूप में समझाएँ।
